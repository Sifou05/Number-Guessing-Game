import random

ans = "1"

while ans == "1": 
    print("Welcome to the game. Before you begin, let's take a quick look at the rules!")
    print("I am going to think of a random number between 1 and 100. You have a certain number of chances to guess it!")
    print("How difficult would you like the game to be:")
    print("Easy (1)")
    print("Medium (2)")
    print("Hard (3)")
    print("Impossible (4)")
    
    answer = input()
    chances = 0
    
    if answer == "1":
        chances = 10
    elif answer == "2":
        chances = 5
    elif answer == "3":
        chances = 3
    elif answer == "4":
        chances = 1
    else:
        print("Invalid input! Defaulting to Impossible mode.")
        chances = 1   # <-- only here!

    print("Okay then, you got", chances, "chances!")
    print("Let's begin!")
    
    pc_ans = random.randint(1, 100)

    while chances > 0:
        guess = int(input("Enter your guess: "))
        if guess == pc_ans:
            print("Congratulations! You guessed it!")
            break
        else:
            chances -= 1
            if chances > 0:
                print("Oops! Try again! You have", chances, "chances left.")
            else:
                print("Out of chances! The PC picked:", pc_ans)
    
    print("Would you like to play again? Yes or No? (1/0)")
    ans = input()
